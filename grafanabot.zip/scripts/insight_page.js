var request = require('request');
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
var function_call = function (dash_name, callback_insight_page) {
	var dash_name = dash_name;
var headers = {
    'Authorization': 'Bearer '+process.env.HUBOT_GRAFANA_API_KEY
};

var options = {
    url: process.env.HUBOT_GRAFANA_HOST+'/api/dashboards/db/'+dash_name,
    headers: headers
};

function callback(error, response, body) {
    if (!error && response.statusCode == 200) {
        //console.log(body);
		body = JSON.parse(body);
		//console.log(body.length);
		var final_string = '';
		var count = 0;
		for(i=0;i<body.dashboard.rows.length;i++)
		{
			
			for(j=0;j<body.dashboard.rows[i].panels.length;j++)
			{
				
				count= count + 1;
				final_string = final_string + count + '--> Panel-ID :: ' + body.dashboard.rows[i].panels[j].id + ' -- Source :: ' + body.dashboard.rows[i].panels[j].datasource + ' -- Panel-Name :: ' + body.dashboard.rows[i].panels[j].title + ' -- DataBase Type :: '+ body.dashboard.rows[i].panels[j].type+'\n';
			}
		}
		callback_insight_page(null,final_string,null);
    }
	else
	{
		callback_insight_page("Something went wrong","Something went wrong","Something went wrong");
	}
}

request(options, callback);
}






module.exports = {
 insight_page: function_call	// MAIN FUNCTION
  
}