
var Datastore = require('./node_modules/nedb');  
var users = new Datastore({ filename: 'users.db', autoload: true });  


var scott = {  
    name: 'Scott123234234',
    twitter: '@ScottWRobinsondfbbbv',
	count: 1
};

/*
users.insert(scott, function(err, doc) {  
    console.log('Inserted', doc.name, 'with ID', doc._id);
});

*/
/*
users.findOne({ twitter: '@ScottWRobinsondfbbbv' }, function(err, doc) {  
    console.log(doc);
    
});
*/

users.update({ twitter: '@ScottWRobinsondfbbbv' }, { $inc: { count: 1 } }, {returnUpdatedDocs: true}, function (err, doc) {
  
});


users.findOne({ twitter: '@ScottWRobinsondfbbbv' }, function(err, doc) {  
    console.log(doc);
    
});


